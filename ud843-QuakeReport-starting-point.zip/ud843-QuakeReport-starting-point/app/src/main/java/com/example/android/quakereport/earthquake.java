package com.example.android.quakereport;

public class earthquake {

    private Double mMagnitude;
    private String mLocation;
    private Long mDate;

    earthquake(Double magnitude, String location, Long date){
        mMagnitude=magnitude;
        mLocation=location;
        mDate=date;
    }

    public Double getmMagnitude() {
        return mMagnitude;
    }

    public String getmLocation() {
        return mLocation;
    }

    public long getTimeInMilliseconds() {
        return mDate;
    }
}
